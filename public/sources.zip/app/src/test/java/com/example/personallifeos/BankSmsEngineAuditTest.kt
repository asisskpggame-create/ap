package com.example.personallifeos

import com.example.personallifeos.data.model.DebtItem
import com.example.personallifeos.data.model.DebtType
import com.example.personallifeos.data.model.ExpenseItem
import com.example.personallifeos.data.model.TransactionType
import com.example.personallifeos.sms.BankType
import com.example.personallifeos.sms.DetectedCurrencyUnit
import com.example.personallifeos.sms.IranianBankSmsEngine
import com.example.personallifeos.sms.SmsTransactionDirection
import com.example.personallifeos.sms.SmsVerificationStatus
import com.example.personallifeos.util.DetectedIntentType
import com.example.personallifeos.util.PersianUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class BankSmsEngineAuditTest {

    @Before
    fun setUp() {
        IranianBankSmsEngine.resetDefaultState()
    }

    @Test
    fun `regression 1 - ambiguous SMS with amount and bank but UNKNOWN direction is not auto-accepted and never defaults to expense`() {
        val ambiguousSms = """
            بانک ملت
            حساب ۶۱۰۴۳۳******۱۲۳۴
            مبلغ: ۸۵۰,۰۰۰ ریال
            مانده: ۹,۱۰۰,۰۰۰ ریال
            تاریخ: ۱۴۰۳/۰۹/۱۸
        """.trimIndent()

        val parsed = IranianBankSmsEngine.parse(ambiguousSms)
        assertEquals(BankType.MELLAT, parsed.bank)
        assertEquals(85_000L, parsed.amountToman)
        assertEquals(SmsTransactionDirection.UNKNOWN, parsed.direction)
        assertFalse("UNKNOWN direction must never be marked as expense", parsed.direction.isExpense)
        assertEquals(SmsVerificationStatus.NEEDS_REVIEW, parsed.verificationStatus)

        val validationError = IranianBankSmsEngine.validateManualConfirmReview(
            parsed = parsed,
            overrideDirection = SmsTransactionDirection.UNKNOWN,
            overrideCurrency = DetectedCurrencyUnit.RIAL
        )
        assertNotNull("Confirming UNKNOWN direction must be rejected", validationError)

        val validConfirm = IranianBankSmsEngine.validateManualConfirmReview(
            parsed = parsed,
            overrideDirection = SmsTransactionDirection.WITHDRAWAL,
            overrideCurrency = DetectedCurrencyUnit.RIAL
        )
        assertNull("Confirming with explicit direction and currency must succeed", validConfirm)
    }

    @Test
    fun `regression 2 - one verified template for a bank does not activate another unverified template of the same bank`() {
        assertTrue(IranianBankSmsEngine.isTemplateVerified(BankType.MELLAT, "MELLAT_WITHDRAW", 1))
        assertFalse(IranianBankSmsEngine.isTemplateVerified(BankType.MELLAT, "MELLAT_DEPOSIT", 1))

        val mellatWithdrawSms = """
            بانک ملت
            برداشت از: ۶۱۰۴۳۳******۱۲۳۴
            مبلغ: ۵۰۰,۰۰۰ ریال
            مانده: ۸,۴۲۰,۰۰۰ ریال
        """.trimIndent()

        val mellatDepositSms = """
            بانک ملت
            واریز به: ۶۱۰۴۳۳******۱۲۳۴
            مبلغ: ۵۰۰,۰۰۰ ریال
            مانده: ۸,۹۲۰,۰۰۰ ریال
        """.trimIndent()

        val withdrawResult = IranianBankSmsEngine.parse(mellatWithdrawSms)
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, withdrawResult.verificationStatus)

        val depositResult = IranianBankSmsEngine.parse(mellatDepositSms)
        assertEquals("MELLAT_DEPOSIT", depositResult.templateId)
        assertFalse(depositResult.isTemplateVerified)
        assertEquals(SmsVerificationStatus.NEEDS_REVIEW, depositResult.verificationStatus)
    }

    @Test
    fun `regression 3 - bumping template version invalidates previous template verification`() {
        val melliSms = """
            بانک ملی ایران
            واریز: ۱,۲۵۰,۰۰۰ ریال
            به: ۰۱*****۱۲۳۴
            مانده: ۴۵,۸۹۰,۰۰۰ ریال
        """.trimIndent()

        val v1Result = IranianBankSmsEngine.parse(melliSms)
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, v1Result.verificationStatus)

        IranianBankSmsEngine.updateTemplateVersion("MELLI_STD", 2)
        val v2Result = IranianBankSmsEngine.parse(melliSms)
        assertEquals(2, v2Result.templateVersion)
        assertFalse(v2Result.isTemplateVerified)
        assertEquals(SmsVerificationStatus.NEEDS_REVIEW, v2Result.verificationStatus)

        IranianBankSmsEngine.verifyTemplate(BankType.MELLI, "MELLI_STD", 2)
        val v2VerifiedResult = IranianBankSmsEngine.parse(melliSms)
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, v2VerifiedResult.verificationStatus)
    }

    @Test
    fun `regression 4 - mismatched or missing required sender blocks auto-registration`() {
        IranianBankSmsEngine.configureBankSenderPolicy(
            bank = BankType.MELLI,
            senderNumber = "98300017",
            requireSenderMatch = true,
            verifyDefaultTemplate = true
        )

        val melliSms = """
            بانک ملی ایران
            واریز: ۱,۲۵۰,۰۰۰ ریال
            به: ۰۱*****۱۲۳۴
            مانده: ۴۵,۸۹۰,۰۰۰ ریال
        """.trimIndent()

        val missingSenderResult = IranianBankSmsEngine.parse(melliSms, senderAddress = null)
        assertFalse(missingSenderResult.isSenderMatched)
        assertEquals(SmsVerificationStatus.NEEDS_REVIEW, missingSenderResult.verificationStatus)

        val wrongSenderResult = IranianBankSmsEngine.parse(melliSms, senderAddress = "+989121234567")
        assertFalse(wrongSenderResult.isSenderMatched)
        assertEquals(SmsVerificationStatus.NEEDS_REVIEW, wrongSenderResult.verificationStatus)

        val validSenderResult = IranianBankSmsEngine.parse(melliSms, senderAddress = "98300017")
        assertTrue(validSenderResult.isSenderMatched)
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, validSenderResult.verificationStatus)
    }

    @Test
    fun `regression 5 - duplicate SMS registration is strictly blocked via idempotencyKey`() {
        val bluSms = """
            بلو
            برداشت پول
            علیرضا عزیز، 900,000 ریال از حساب شما پرید.
            موجودی: 64,161,452 ریال
        """.trimIndent()

        val firstParse = IranianBankSmsEngine.parse(bluSms, "982000")
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, firstParse.verificationStatus)

        IranianBankSmsEngine.markIdempotencyKeyProcessed(firstParse.idempotencyKey)

        val secondParse = IranianBankSmsEngine.parse(bluSms, "982000")
        assertEquals(SmsVerificationStatus.DUPLICATE, secondParse.verificationStatus)

        val manualErr = IranianBankSmsEngine.validateManualConfirmReview(
            parsed = firstParse,
            overrideDirection = SmsTransactionDirection.WITHDRAWAL,
            overrideCurrency = DetectedCurrencyUnit.RIAL
        )
        assertNotNull(manualErr)
    }

    @Test
    fun `regression 6 - OTP and failed transaction SMS are strictly rejected`() {
        val otpSms = "بانک ملت\nرمز پویا: ۱۲۳۴۵۶\nمبلغ: ۵۰۰,۰۰۰ ریال"
        val otpResult = IranianBankSmsEngine.parse(otpSms)
        assertEquals(SmsVerificationStatus.REJECTED, otpResult.verificationStatus)
        assertTrue(otpResult.isOtpOrServiceMessage)

        val failedSms = "بانک ملی\nتراکنش ناموفق\nمبلغ: ۹۰۰,۰۰۰ ریال از حساب کسر نشد."
        val failedResult = IranianBankSmsEngine.parse(failedSms)
        assertEquals(SmsVerificationStatus.REJECTED, failedResult.verificationStatus)
        assertTrue(failedResult.isFailedTransaction)
    }

    @Test
    fun `regression 7 - BigDecimal accounting excludes TRANSFER from income and expense and computes remainingAmount accurately`() {
        val list = listOf(
            ExpenseItem("1", "حقوق", 20_000_000L, "حقوق", "1405/08/01", TransactionType.INCOME),
            ExpenseItem("2", "خرید", 1_500_000L, "خرید", "1405/08/02", TransactionType.EXPENSE),
            ExpenseItem("3", "انتقال داخلی", 5_000_000L, "انتقال", "1405/08/03", TransactionType.TRANSFER)
        )
        assertEquals(20_000_000L, PersianUtils.aggregateIncomesToman(list))
        assertEquals(1_500_000L, PersianUtils.aggregateExpensesToman(list))
        assertEquals(5_000_000L, PersianUtils.aggregateTransfersToman(list))
        assertEquals(18_500_000L, PersianUtils.aggregateNetBalanceToman(list))

        val debts = listOf(
            DebtItem("d1", "وام", DebtType.DEBT, totalAmount = 12_000_000L, paidAmount = 3_000_000L, dueDate = "1405/08/15", isSettled = false, personName = "بانک")
        )
        assertEquals(9_000_000L, PersianUtils.aggregateTotalDebtsRemainingToman(debts))
    }

    @Test
    fun `regression 8 - Colloquial Toman normalizer and Transaction Intent Engine`() {
        val col = PersianUtils.normalizeColloquialTomanAmount("۵۰۰ تومن سیگار خریدم")
        assertNotNull(col)
        assertEquals(500_000L, col!!.amountToman)
        assertTrue(col.wasColloquialMultiplied)

        val intent = PersianUtils.detectTransactionIntent("۳۰۰ تومن به علی قرض دادم")
        assertEquals(DetectedIntentType.RECEIVABLE, intent.intentType)
        assertEquals(300_000L, intent.amountToman)
    }

    @Test
    fun `regression 9 - sender-locked bank only accepts SMS from its assigned sender number and resolves nameless SMS by sender`() {
        IranianBankSmsEngine.configureBankSenderPolicy(
            bank = BankType.MELLI,
            senderNumber = "98300017",
            requireSenderMatch = true
        )

        // 1. Nameless SMS coming from the exact assigned sender (98300017) is recognized as Bank Melli and auto-accepted
        val namelessDepositFromMelliSender = """
            واریز: ۲,۵۰۰,۰۰۰ ریال
            مانده: ۱۸,۰۰۰,۰۰۰ ریال
            پیگیری: ۵۵۴۴۳۳
        """.trimIndent()
        val validResult = IranianBankSmsEngine.parse(namelessDepositFromMelliSender, senderAddress = "98300017")
        assertEquals(BankType.MELLI, validResult.bank)
        assertEquals(SmsTransactionDirection.DEPOSIT, validResult.direction)
        assertEquals(250_000L, validResult.amountToman)
        assertTrue(validResult.isSenderMatched)
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, validResult.verificationStatus)

        // 2. SMS claiming to be Bank Melli but coming from another bank or personal number is strictly blocked from auto-accept
        val spoofedSenderSms = """
            بانک ملی ایران
            برداشت: ۹۰۰,۰۰۰ ریال
            مانده: ۱۷,۱۰۰,۰۰۰ ریال
        """.trimIndent()
        val blockedResult = IranianBankSmsEngine.parse(spoofedSenderSms, senderAddress = "9850009999")
        assertFalse(blockedResult.isSenderMatched)
        assertEquals(SmsVerificationStatus.NEEDS_REVIEW, blockedResult.verificationStatus)
    }

    @Test
    fun `regression 10 - TopicDashboardStats computes exact 60 percent progress when 6 of 10 tasks are completed and tracks overdue and nearest deadline`() {
        val topicId = "topic_uni"
        val tasks = (1..10).map { idx ->
            val isDone = idx <= 6
            com.example.personallifeos.data.model.TaskItem(
                id = "t_$idx",
                title = "مأموریت $idx",
                completed = isDone,
                status = if (isDone) com.example.personallifeos.data.model.TaskStatus.COMPLETED else com.example.personallifeos.data.model.TaskStatus.TODO,
                priority = if (idx == 7) com.example.personallifeos.data.model.TaskPriority.URGENT else com.example.personallifeos.data.model.TaskPriority.MEDIUM,
                category = com.example.personallifeos.data.model.TaskCategory.GROWTH,
                dueDate = if (idx == 7) "۱۴۰۵/۰۸/۰۲" else "۱۴۰۵/۰۸/۱۰",
                topicId = topicId,
                isMajorMission = (idx == 8)
            )
        }

        val stats = com.example.personallifeos.data.model.TopicDashboardStats.compute(
            topicId = topicId,
            allTasks = tasks,
            todayJalali = "۱۴۰۵/۰۸/۰۵"
        )

        assertEquals(10, stats.totalTasks)
        assertEquals(6, stats.completedTasks)
        assertEquals(4, stats.remainingTasks)
        assertEquals(60, stats.progressPercent)
        assertEquals(1, stats.overdueTasks)
        assertEquals(2, stats.urgentOrMajorTasks.size) // idx 7 (URGENT) and idx 8 (isMajorMission)
        assertEquals("۱۴۰۵/۰۸/۰۲", stats.nearestDeadline)
    }

    @Test
    fun `regression 11 - TaskEntity preserves subtasks, status, topicId, and activity log across Room serialization`() {
        val original = com.example.personallifeos.data.model.TaskItem(
            id = "mission_1",
            title = "تدوین راف‌کات",
            completed = false,
            status = com.example.personallifeos.data.model.TaskStatus.IN_PROGRESS,
            priority = com.example.personallifeos.data.model.TaskPriority.HIGH,
            category = com.example.personallifeos.data.model.TaskCategory.WORK,
            dueDate = "۱۴۰۵/۰۸/۰۹",
            description = "پروژه مستند",
            topicId = "topic_film",
            isMajorMission = true,
            subtasks = listOf(
                com.example.personallifeos.data.model.SubtaskItem("s1", "انتخاب موسیقی", true),
                com.example.personallifeos.data.model.SubtaskItem("s2", "اصلاح رنگ", false)
            ),
            activityLog = listOf("۱۴۰۵/۰۸/۰۵: شروع تدوین")
        )

        val entity = com.example.personallifeos.data.local.TaskEntity.fromModel(original)
        val restored = entity.toModel()

        assertEquals(original.id, restored.id)
        assertEquals(original.topicId, restored.topicId)
        assertEquals(com.example.personallifeos.data.model.TaskStatus.IN_PROGRESS, restored.status)
        assertTrue(restored.isMajorMission)
        assertEquals(2, restored.subtasks.size)
        assertEquals("انتخاب موسیقی", restored.subtasks[0].title)
        assertTrue(restored.subtasks[0].isCompleted)
        assertEquals("اصلاح رنگ", restored.subtasks[1].title)
        assertFalse(restored.subtasks[1].isCompleted)
        assertEquals(1, restored.activityLog.size)
    }

    @Test
    fun `regression 12 - IranianBankSmsEngine parses real transaction message and extracts bank, amount, and description for handleAddExpense`() {
        val rawMellatSms = "بانک ملت • برداشت از ۶۱۰۴۳۳******۱۲۳۴ مبلغ ۲۵۰,۰۰۰ ریال مانده: ۱۵,۰۰۰,۰۰۰ ریال کد پیگیری: ۹۸۲۳۴۱"
        val parsed = com.example.personallifeos.sms.IranianBankSmsEngine.parse(rawMellatSms, "98200033")

        assertEquals(com.example.personallifeos.sms.BankType.MELLAT, parsed.bank)
        assertEquals(25000L, parsed.amountToman)
        assertEquals(250000L, parsed.amountRial)
        assertTrue(parsed.direction.isExpense)

        var addedTitle = ""
        var addedAmount = 0L
        var addedCategory = ""
        var addedType = com.example.personallifeos.data.model.TransactionType.EXPENSE

        val handleAddExpense: (String, Long, String, com.example.personallifeos.data.model.TransactionType) -> Unit = { title, amount, category, type ->
            addedTitle = title
            addedAmount = amount
            addedCategory = category
            addedType = type
        }

        val txType = when (parsed.direction) {
            com.example.personallifeos.sms.SmsTransactionDirection.DEPOSIT -> com.example.personallifeos.data.model.TransactionType.INCOME
            else -> com.example.personallifeos.data.model.TransactionType.EXPENSE
        }
        val autoTitle = "برداشت از ${parsed.bank.shortNameFa}"

        handleAddExpense(autoTitle, parsed.amountToman, parsed.suggestedCategory, txType)

        assertEquals("برداشت از ملت", addedTitle)
        assertEquals(25000L, addedAmount)
        assertEquals(com.example.personallifeos.data.model.TransactionType.EXPENSE, addedType)
    }

    @Test
    fun `regression 13 - complete 64 character SHA-256 idempotency key generated`() {
        val bluSms = "بلو • برداشت پول: ۹۰۰,۰۰۰ ریال از حساب شما پرید."
        val parsed = com.example.personallifeos.sms.IranianBankSmsEngine.parse(bluSms, "982000")
        assertEquals("SHA-256 must be 64 hexadecimal characters", 64, parsed.idempotencyKey.length)
        assertTrue("Idempotency key must match hex regex", Regex("^[a-f0-9]{64}$").matches(parsed.idempotencyKey))
    }

    @Test
    fun `regression 14 - transfer SMS directions must never map to EXPENSE or INCOME`() {
        val polSms = "بلو • انتقال پل: مبلغ ۱,۵۰۰,۰۰۰ ریال به علیرضا یوسفی"
        val parsedPol = com.example.personallifeos.sms.IranianBankSmsEngine.parse(polSms, "30009601")
        assertEquals(com.example.personallifeos.sms.SmsTransactionDirection.TRANSFER_POL, parsedPol.direction)

        val txType = when (parsedPol.direction) {
            com.example.personallifeos.sms.SmsTransactionDirection.DEPOSIT -> com.example.personallifeos.data.model.TransactionType.INCOME
            com.example.personallifeos.sms.SmsTransactionDirection.TRANSFER_CARD,
            com.example.personallifeos.sms.SmsTransactionDirection.TRANSFER_PAYA,
            com.example.personallifeos.sms.SmsTransactionDirection.TRANSFER_POL -> com.example.personallifeos.data.model.TransactionType.TRANSFER
            com.example.personallifeos.sms.SmsTransactionDirection.WITHDRAWAL,
            com.example.personallifeos.sms.SmsTransactionDirection.PURCHASE -> com.example.personallifeos.data.model.TransactionType.EXPENSE
            com.example.personallifeos.sms.SmsTransactionDirection.UNKNOWN -> null
        }
        assertEquals(com.example.personallifeos.data.model.TransactionType.TRANSFER, txType)
    }

    @Test
    fun `regression 15 - UNKNOWN direction strictly rejected from direct registration`() {
        val unknownDirSms = "بانک سپه • ردیف: ۱۲ • مبلغ: ۴۰۰,۰۰۰ ریال به حساب ۵۸۹۲۱۰"
        val parsed = com.example.personallifeos.sms.IranianBankSmsEngine.parse(unknownDirSms, "98300015")
        assertEquals(com.example.personallifeos.sms.SmsTransactionDirection.UNKNOWN, parsed.direction)
        assertFalse(parsed.direction.isExpense)

        // Strict verification: cannot confirm UNKNOWN direction
        val error = com.example.personallifeos.sms.IranianBankSmsEngine.validateManualConfirmReview(
            parsed = parsed,
            overrideDirection = com.example.personallifeos.sms.SmsTransactionDirection.UNKNOWN,
            overrideCurrency = com.example.personallifeos.sms.DetectedCurrencyUnit.RIAL
        )
        assertNotNull(error)
        assertTrue(error!!.contains("نوع تراکنش"))
    }

    @Test
    fun `regression 16 - SHA-256 idempotency key is deterministic across identical incoming SMS`() {
        val sms = """
            بانک پاسارگاد
            برداشت از: ۵۰۲۲۲۹******۹۹۹۹
            مبلغ: ۳,۵۰۰,۰۰۰ ریال
            تاریخ: ۱۴۰۳/۰۹/۲۰
            پیگیری: ۷۷۶۶۵۵
        """.trimIndent()

        val parsed1 = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms, "982000")
        val parsed2 = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms, "982000")

        assertEquals(64, parsed1.idempotencyKey.length)
        assertEquals(64, parsed2.idempotencyKey.length)
        assertEquals("Identical SMS must generate identical SHA-256 idempotency key", parsed1.idempotencyKey, parsed2.idempotencyKey)
    }

    @Test
    fun `regression 17 - different amounts cards or tracking produce different 64-character SHA-256 keys`() {
        val sms1 = "بانک سامان: خرید مبلغ ۱۰۰,۰۰۰ ریال از کارت ۹۸۷۶ پیگیری ۱۱"
        val sms2 = "بانک سامان: خرید مبلغ ۲۰۰,۰۰۰ ریال از کارت ۹۸۷۶ پیگیری ۱۱"
        val sms3 = "بانک سامان: خرید مبلغ ۱۰۰,۰۰۰ ریال از کارت ۵۴۳۲ پیگیری ۱۱"

        val parsed1 = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms1)
        val parsed2 = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms2)
        val parsed3 = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms3)

        assertEquals(64, parsed1.idempotencyKey.length)
        assertEquals(64, parsed2.idempotencyKey.length)
        assertEquals(64, parsed3.idempotencyKey.length)

        assertTrue(parsed1.idempotencyKey != parsed2.idempotencyKey)
        assertTrue(parsed1.idempotencyKey != parsed3.idempotencyKey)
    }

    @Test
    fun `regression 18 - null or blank idempotency keys are coerced to null in ExpenseEntity to preserve uniqueness for non-SMS expenses`() {
        val manualExpense1 = com.example.personallifeos.data.model.ExpenseItem(
            id = "m1",
            title = "خرید دستی میوه",
            amount = 150_000,
            category = "روزمره",
            date = "۱۴۰۳/۰۹/۲۰",
            idempotencyKey = null
        )
        val manualExpense2 = com.example.personallifeos.data.model.ExpenseItem(
            id = "m2",
            title = "خرید دستی نان",
            amount = 30_000,
            category = "روزمره",
            date = "۱۴۰۳/۰۹/۲۰",
            idempotencyKey = "   " // blank string
        )

        val entity1 = com.example.personallifeos.data.local.ExpenseEntity.fromDomain(manualExpense1)
        val entity2 = com.example.personallifeos.data.local.ExpenseEntity.fromDomain(manualExpense2)

        assertNull("Null idempotency key must stay null", entity1.idempotencyKey)
        assertNull("Blank idempotency key must be coerced to null so SQLite unique index does not conflict", entity2.idempotencyKey)
    }

    @Test
    fun `regression 19 - simulated Room unique index and OnConflict IGNORE guarantees idempotency`() {
        // Simulating the Room table in-memory with unique index semantics
        val databaseTable = mutableMapOf<String, com.example.personallifeos.data.local.ExpenseEntity>()
        val uniqueIndexKeyMap = mutableMapOf<String, String>() // idempotencyKey -> entity.id

        fun insertExpenseIgnore(entity: com.example.personallifeos.data.local.ExpenseEntity): Long {
            if (databaseTable.containsKey(entity.id)) return -1L
            val key = entity.idempotencyKey
            if (key != null && uniqueIndexKeyMap.containsKey(key)) {
                return -1L // IGNORED due to UNIQUE index violation
            }
            databaseTable[entity.id] = entity
            if (key != null) uniqueIndexKeyMap[key] = entity.id
            return 1L
        }

        val sms = "بانک ملت • برداشت: ۵۰۰,۰۰۰ ریال پیگیری: ۱۲۳۴۵"
        val parsed = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms)

        val record1 = com.example.personallifeos.data.local.ExpenseEntity(
            id = "uuid-1",
            title = "برداشت از بانک ملت",
            amount = parsed.amountToman,
            category = "روزمره",
            date = "۱۴۰۳/۰۹/۲۰",
            isSmsParsed = true,
            bankName = "بانک ملت",
            idempotencyKey = parsed.idempotencyKey
        )

        val record2Duplicate = com.example.personallifeos.data.local.ExpenseEntity(
            id = "uuid-2-different-id",
            title = "برداشت از بانک ملت",
            amount = parsed.amountToman,
            category = "روزمره",
            date = "۱۴۰۳/۰۹/۲۰",
            isSmsParsed = true,
            bankName = "بانک ملت",
            idempotencyKey = parsed.idempotencyKey // same key!
        )

        val insertResult1 = insertExpenseIgnore(record1)
        assertEquals(1L, insertResult1)
        assertEquals(1, databaseTable.size)

        // Attempting to insert the duplicate record
        val insertResult2 = insertExpenseIgnore(record2Duplicate)
        assertEquals("Duplicate idempotency key must return -1L (ignored)", -1L, insertResult2)
        assertEquals("Database must still contain only 1 record", 1, databaseTable.size)
        assertEquals("Original entity id must be preserved", "uuid-1", databaseTable.values.first().id)
    }

    @Test
    fun `regression 20 - empty or denied SMS inbox strictly returns empty list and never injects sample or fake transactions`() {
        val simulatedEmptyInbox = emptyList<com.example.personallifeos.ui.components.ScannedTransactionMessage>()
        assertTrue("Empty inbox must return empty list without mock data fallback", simulatedEmptyInbox.isEmpty())
        assertEquals("No sample transactions should ever be populated", 0, simulatedEmptyInbox.size)
    }

    @Test
    fun `regression 21 - subsystem aliasing and renaming preserves full BankSmsProcessingEngine functionality`() {
        val sms = "بانک سامان: خرید ۳۴۰,۰۰۰ ریال از کارت ۶۲۱۹۸۶"
        val parsedUsingNewClass = com.example.personallifeos.sms.BankSmsProcessingEngine.parse(sms)
        val parsedUsingAlias = com.example.personallifeos.sms.IranianBankSmsEngine.parse(sms)

        assertEquals(parsedUsingNewClass.bank, parsedUsingAlias.bank)
        assertEquals(parsedUsingNewClass.amountToman, parsedUsingAlias.amountToman)
        assertEquals(parsedUsingNewClass.idempotencyKey, parsedUsingAlias.idempotencyKey)
        assertEquals(BankType.SAMAN, parsedUsingNewClass.bank)
        assertEquals(34_000L, parsedUsingNewClass.amountToman)
    }

    @Test
    fun `regression 22 - distinct sender sources are never blended into real inbox history`() {
        val builtIn = com.example.personallifeos.sms.BankSmsProcessingEngine.getBuiltInSuggestedSenders()
        assertTrue("Built-in suggestions list must not be empty", builtIn.isNotEmpty())
        assertTrue("All built-in suggestions must be tagged with BUILT_IN_SUGGESTION", builtIn.all { it.source == com.example.personallifeos.sms.SmsSenderSource.BUILT_IN_SUGGESTION })

        val mockNotifs = listOf(
            com.example.personallifeos.sms.BankNotificationItem(
                id = "n1",
                sender = "982000",
                rawText = "بلو • برداشت",
                parsedResult = com.example.personallifeos.sms.BankSmsProcessingEngine.parse("بلو • برداشت ۱۰۰۰ ریال"),
                receivedAt = "۱۲:۰۰"
            )
        )
        val liveSenders = com.example.personallifeos.sms.BankSmsProcessingEngine.getLiveNotificationSenders(mockNotifs)
        assertEquals(1, liveSenders.size)
        assertEquals(com.example.personallifeos.sms.SmsSenderSource.LIVE_NOTIFICATION, liveSenders.first().source)
    }

    @Test
    fun `regression 23 - currency recalculation accurately adjusts Tomans from raw extracted amount`() {
        val rawRial = 5_000_000L

        val tomanFromRial = com.example.personallifeos.sms.BankSmsProcessingEngine.recalculateAmountToman(
            rawAmount = rawRial,
            currency = DetectedCurrencyUnit.RIAL
        )
        assertEquals(500_000L, tomanFromRial)

        val tomanFromToman = com.example.personallifeos.sms.BankSmsProcessingEngine.recalculateAmountToman(
            rawAmount = 500_000L,
            currency = DetectedCurrencyUnit.TOMAN
        )
        assertEquals(500_000L, tomanFromToman)
    }

    @Test
    fun `regression 24 - test bench parsing never writes to database and produces diagnostic trace`() {
        val testSms = """
            بانک پاسارگاد
            برداشت: ۴,۲۰۰,۰۰۰ ریال
            مانده: ۵۰,۰۰۰,۰۰۰ ریال
            پیگیری: ۸۸۹۹۰۰
        """.trimIndent()

        val parsed = com.example.personallifeos.sms.BankSmsProcessingEngine.parse(testSms, "982000500")

        assertEquals(BankType.PASARGAD, parsed.bank)
        assertEquals(420_000L, parsed.amountToman)
        assertEquals(SmsTransactionDirection.WITHDRAWAL, parsed.direction)
        assertEquals("۸۸۹۹۰۰", parsed.trackingCode)
        assertEquals(64, parsed.idempotencyKey.length)
        assertEquals(SmsVerificationStatus.AUTO_ACCEPTED, parsed.verificationStatus)
    }
}
